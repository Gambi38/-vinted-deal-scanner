#!/usr/bin/env python3
import json
import sys
import urllib.request

print("=== Configuration Telegram ===")
token = input("Colle le TOKEN donné par @BotFather : ").strip()
if not token:
    print("Token vide.")
    sys.exit(1)

print("\n1) Ouvre ton bot dans Telegram.")
print("2) Appuie sur START ou envoie-lui simplement : test")
input("3) Quand c'est fait, appuie sur Entrée ici... ")

url = f"https://api.telegram.org/bot{token}/getUpdates"
try:
    with urllib.request.urlopen(url, timeout=20) as r:
        data = json.loads(r.read().decode("utf-8"))
except Exception as e:
    print("Erreur Telegram :", e)
    sys.exit(1)

results = data.get("result", [])
found = []
for upd in results:
    msg = upd.get("message") or upd.get("channel_post") or {}
    chat = msg.get("chat") or {}
    cid = chat.get("id")
    if cid is not None:
        name = chat.get("title") or chat.get("username") or chat.get("first_name") or "chat"
        found.append((cid, name))

if not found:
    print("\nAucun chat trouvé. Envoie d'abord un message à ton bot puis relance ce script.")
else:
    print("\nChat(s) trouvé(s) :")
    for cid, name in dict.fromkeys(found):
        print(f"  TELEGRAM_CHAT_ID={cid}   ({name})")
    print("\nGarde ton TOKEN secret : toute personne qui le possède peut contrôler ton bot.")
