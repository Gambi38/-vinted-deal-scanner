# Vinted Deal Scanner V3 — 0 € avec GitHub Actions + Telegram

Cette version est conçue pour fonctionner sans serveur payant.
GitHub Actions lance automatiquement un scan Vinted toutes les 5 minutes et envoie
les opportunités détectées vers Telegram.

## Ce qu'il faut
- un compte GitHub gratuit ;
- Telegram ;
- le bot créé avec @BotFather ;
- aucun PC allumé.

## Important
- GitHub impose au minimum 5 minutes entre deux exécutions planifiées.
- Un dépôt PUBLIC utilise gratuitement les runners GitHub standard.
- Un dépôt PRIVÉ dispose d'un quota mensuel de minutes : pour rester à 0 € avec un scan
  fréquent, le dépôt public est donc le plus simple.
- Ne mets JAMAIS le token Telegram dans un fichier du dépôt : utilise GitHub Secrets.
- Le scanner ne contourne pas CAPTCHA ou protections anti-bot. Vinted peut bloquer certains
  accès venant de datacenters, auquel cas cette méthode peut nécessiter une autre solution.

## Installation depuis iPad

### 1. Créer un dépôt GitHub
Sur github.com :
1. + > New repository
2. Nom : `vinted-deal-scanner`
3. Choisir Public
4. Create repository

### 2. Envoyer les fichiers
Décompresse ce ZIP dans l'app Fichiers de l'iPad puis ajoute son contenu à la racine du dépôt.
Le dossier `.github/workflows/` doit être conservé avec son fichier `vinted-scan.yml`.

### 3. Ajouter les secrets Telegram
Dans le dépôt :
Settings > Secrets and variables > Actions > New repository secret

Créer :
- `TELEGRAM_BOT_TOKEN` = token donné par @BotFather
- `TELEGRAM_CHAT_ID` = identifiant de ton chat Telegram

### 4. Trouver le Chat ID sans PC
Après avoir envoyé un message à ton bot Telegram, ouvre dans Safari :
`https://api.telegram.org/bot<TON_TOKEN>/getUpdates`

Dans le résultat, cherche :
`"chat":{"id":123456789,...}`

Le nombre est ton `TELEGRAM_CHAT_ID`.
Ne partage pas la page ni ton token.

### 5. Activer le scanner
Dans GitHub :
Actions > Vinted Deal Scanner > Run workflow

Le workflow est aussi programmé automatiquement toutes les 5 minutes.

## Fichiers principaux
- `config.json` : produits, plafonds d'achat, revente, marge minimum.
- `vinted_scraper.py` : scanner.
- `.github/workflows/vinted-scan.yml` : lancement automatique.
- `seen.json` : annonces déjà traitées.
- `alerts.csv` : historique des alertes.

## Modifier les recherches
Dans `config.json`, adapte :
- `query`
- `price_to`
- `resale_low`
- `resale_high`
- `min_margin`

## Sécurité
Le token Telegram doit uniquement être enregistré dans GitHub Secrets.
